-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: edulink
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `enrollments`
--

DROP TABLE IF EXISTS `enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollments` (
  `enrollment_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `major_id` int NOT NULL,
  `attendance_year_id` int NOT NULL,
  `is_active` tinyint NOT NULL,
  `university_id` int NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  KEY `fk_enrollments_students1_idx` (`student_id`),
  KEY `fk_enrollments_majors1_idx` (`major_id`),
  KEY `fk_enrollments_attendance_years1_idx` (`attendance_year_id`),
  KEY `fk_enrollments_university1` (`university_id`),
  CONSTRAINT `fk_enrollments_attendance_years1` FOREIGN KEY (`attendance_year_id`) REFERENCES `attendance_years` (`attendance_year_id`),
  CONSTRAINT `fk_enrollments_majors1` FOREIGN KEY (`major_id`) REFERENCES `majors` (`major_id`),
  CONSTRAINT `fk_enrollments_students1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `fk_enrollments_university1` FOREIGN KEY (`university_id`) REFERENCES `universities` (`university_id`)
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollments`
--

LOCK TABLES `enrollments` WRITE;
/*!40000 ALTER TABLE `enrollments` DISABLE KEYS */;
INSERT INTO `enrollments` VALUES (1,1,12,6,1,1),(2,2,6,6,1,1),(3,3,2,13,1,3),(4,4,2,18,1,4),(5,5,3,24,1,5),(6,6,3,3,1,1),(7,7,4,8,1,2),(8,8,4,14,1,3),(9,9,5,19,1,4),(10,10,5,24,1,5),(11,11,6,6,1,1),(12,12,6,8,1,2),(13,13,120,15,1,3),(14,14,120,18,1,4),(15,15,121,25,1,5),(16,16,121,4,1,1),(17,17,122,10,1,2),(18,18,122,16,1,3),(19,19,123,20,1,4),(20,20,123,25,1,5),(21,21,11,1,1,1),(22,22,11,11,1,2),(23,23,12,17,1,3),(24,24,12,21,1,4),(25,25,13,26,1,5),(26,26,13,3,1,1),(27,27,14,8,1,2),(28,28,14,16,1,3),(29,29,15,18,1,4),(30,30,15,27,1,5),(31,31,16,6,1,1),(32,32,16,7,1,2),(33,33,17,15,1,3),(34,34,17,20,1,4),(35,35,18,28,1,5),(36,36,18,2,1,1),(37,37,19,10,1,2),(38,38,19,14,1,3),(39,39,20,21,1,4),(40,40,20,24,1,5),(41,41,21,5,1,1),(42,42,21,12,1,2),(43,43,22,14,1,3),(44,44,22,19,1,4),(45,45,23,25,1,5),(46,46,23,1,1,1),(47,47,24,2,1,2),(48,48,24,16,1,3),(49,49,25,20,1,4),(50,50,25,26,1,5),(51,51,26,4,1,1),(52,52,26,10,1,2),(53,53,27,17,1,3),(54,54,27,20,1,4),(55,55,28,24,1,5),(56,56,28,6,1,1),(57,57,28,9,1,2),(169,58,6,6,1,1),(170,59,6,6,1,1),(177,69,30,12,1,2),(179,71,6,6,1,1),(180,72,6,6,1,1),(181,73,6,6,1,1),(182,74,6,6,1,1),(183,75,6,6,1,1),(184,76,6,6,1,1),(185,77,6,6,1,1);
/*!40000 ALTER TABLE `enrollments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-12 20:57:07
