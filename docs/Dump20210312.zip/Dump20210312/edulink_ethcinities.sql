-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: edulink
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ethcinities`
--

DROP TABLE IF EXISTS `ethcinities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ethcinities` (
  `ethcinity_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`ethcinity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ethcinities`
--

LOCK TABLES `ethcinities` WRITE;
/*!40000 ALTER TABLE `ethcinities` DISABLE KEYS */;
INSERT INTO `ethcinities` VALUES (1,'Bamar'),(2,'Rohinga'),(3,'Karenni'),(4,'Karen'),(5,'Palaung'),(6,'Wa'),(7,'Mon'),(8,'Pa\'O'),(9,'Kokang Chinese'),(10,'Shan'),(11,'Chinese'),(12,'Rakhine'),(13,'Lisu'),(14,'Kayan'),(15,'Anglo-Burmese'),(16,'Intha'),(17,'Naga'),(18,'Danu'),(19,'Kamein'),(20,'Kachin'),(21,'Akha'),(22,'Panthays'),(23,'Daingnet'),(24,'Jingpo'),(25,'Burmese Indians'),(26,'Nung Rawang'),(27,'Taungyo'),(28,'Barua'),(29,'Chinese'),(30,'Mro-Khimi'),(31,'Bayingyi'),(32,'S\'gaw'),(33,'Taungtha'),(34,'Taron'),(35,'Zotung'),(36,'Khamti'),(37,'Mru'),(38,'Mara'),(39,'Zo'),(40,'Myanmar Tamils'),(41,'Tiddim'),(42,'Hmong'),(43,'Zou'),(44,'Lai'),(45,'Kuki'),(46,'Achang'),(47,'Burmese Gurkha'),(48,'Pakistanis in Myanmar'),(49,'Burmese Malays'),(50,'Zanniat'),(51,'Sizang');
/*!40000 ALTER TABLE `ethcinities` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-12 20:57:08
