-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: edulink
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `donators`
--

DROP TABLE IF EXISTS `donators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `donators` (
  `donator_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `organization_name` varchar(50) DEFAULT NULL,
  `job` varchar(50) DEFAULT NULL,
  `donation_count` int NOT NULL,
  PRIMARY KEY (`donator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donators`
--

LOCK TABLES `donators` WRITE;
/*!40000 ALTER TABLE `donators` DISABLE KEYS */;
INSERT INTO `donators` VALUES (1,'Thet htet san','093456789','nullnull Magaway','A','Manager',2),(2,'Htet','098765432','B, Dagon, Yangon','B','CEO',6),(3,'San','098739000','C, Pazundaung, Yangon','C','Trade',9),(4,'Kyaw','098221144','D, MahaAungMyae, Mandalay','D','Tourism',10),(5,'Mya','095678321','E, Shan','E','IT',0),(6,'Khin','091234587','F, Kachin','F','IT',0),(7,'Aye','095763821','G, Mon','G','Teacher',0),(8,'Yadanar','092431009','H, Rakhin','H','Driver',0),(9,'htet ','093478374','Ayeyarwady, Bogale, dkkjflkdjf',NULL,NULL,1),(10,'htet','93489348','Ayeyarwady, Bogale, sdfjk	',NULL,NULL,1),(11,'dfdf','09347748`','Ayeyarwady, Bogale, dfkjdl	',NULL,NULL,1),(12,'sdfsk','034839','Ayeyarwady, Bogale, djfjsfk',NULL,NULL,1),(13,'htet htet','394934','Ayeyarwady, Bogale, dfsdfsdf',NULL,NULL,1),(14,'name','3343','Ayeyarwady, Bogale, dfkjsdklfj',NULL,NULL,1),(15,'Existing Donator','0988888888','Ayeyarwady, Bogale,  Thie is address....',NULL,NULL,2),(16,'New Donator Updated','098888888','Ayeyarwady, Bogale,  Address...',NULL,NULL,2);
/*!40000 ALTER TABLE `donators` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-12 20:57:07
