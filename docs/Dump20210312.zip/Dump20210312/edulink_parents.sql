-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: edulink
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `parents`
--

DROP TABLE IF EXISTS `parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parents` (
  `parent_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `father_job` varchar(50) NOT NULL,
  `father_phone` varchar(20) NOT NULL,
  `mother_name` varchar(50) NOT NULL,
  `mother_job` varchar(50) NOT NULL,
  `mother_phone` varchar(20) NOT NULL,
  `parent_address` varchar(255) NOT NULL,
  `parent_township_id` int NOT NULL,
  PRIMARY KEY (`parent_id`),
  KEY `fk_parents_students1_idx` (`student_id`),
  KEY `fk_parents_townships1_idx` (`parent_township_id`),
  CONSTRAINT `fk_parents_students1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `fk_parents_townships1` FOREIGN KEY (`parent_township_id`) REFERENCES `townships` (`township_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parents`
--

LOCK TABLES `parents` WRITE;
/*!40000 ALTER TABLE `parents` DISABLE KEYS */;
INSERT INTO `parents` VALUES (1,1,'U Ba Ba','Farmer','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',1),(2,2,'U Myint Swe','Farmer','Shop','09111555666','Daw Mya','09111111111','Pyin Oo Lwin',24),(3,3,'U Ba','Farmer','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(4,4,'U Ba','Farmer','Daw Mya','Shop','09111555666','09111111111','Pyin Oo Lwin',24),(5,5,'U Ba','Farmer','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(6,6,'U Ba','Farmer','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(7,7,'U Ba','Farmer','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(8,8,'U Ba','Farmer','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(9,9,'U Ba','Farmer','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(10,10,'U Ba','Farmer','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(11,11,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(12,12,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(13,13,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(14,14,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(15,15,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(16,16,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(17,17,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(18,18,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(19,19,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(20,20,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(21,21,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(22,22,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(23,23,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(24,24,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(25,25,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(26,26,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(27,27,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(28,28,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(29,29,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(30,30,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(31,31,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(32,32,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(33,33,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(34,34,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(35,35,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(36,36,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(37,37,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(38,38,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(39,39,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(40,40,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(41,41,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(42,42,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(43,43,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(44,44,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(45,45,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(46,46,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(47,47,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(48,48,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(49,49,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(50,50,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(51,51,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(52,52,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(53,53,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(54,54,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(55,55,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(56,56,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(57,57,'U Ba','Worker','09111555666','Daw Mya','Shop','09111111111','Pyin Oo Lwin',24),(58,58,'U ba','sjdfljsd','0939849834','daw mya','jdfsdjklf','3849384','dkfjljf',1),(59,59,'U badfsdf','jdsjf','93849384','jfksdjflsjdlf','dfklsjdlkf','34343434','jfdjfklsd',1),(60,69,'d','sdfsdf','dfsdf','dfsdfsdf','sdfsdf','sdfsdf','dfsdfsdf',1),(61,71,'d','sdfsdf','dfsdf','dfsdfsdf','sdfsdf','sdfsdf','dfsdfsdf',1),(62,72,'d','sdfsdf','dfsdf','dfsdfsdf','sdfsdf','sdfsdf','dfsdfsdf',1),(63,73,'d','sdfsdf','dfsdf','dfsdfsdf','sdfsdf','sdfsdf','dfsdfsdf',1),(64,74,'d','sdfsdf','sdfsdf','dfsdf','dfsdfsdf','sdfsdf','dfsdfsdf',1),(65,75,'d','sdfsdf','dfsdf','dfsdfsdf','sdfsdf','sdfsdf','dfsdfsdf',1),(66,76,'d','sdfsdf','dfsdf','dfsdfsdf','sdfsdf','sdfsdf','dfsdfsdf',1),(67,77,'U Ba','Job1','098888888','Daw Mya','Job2','097777777','Parent Addr',1);
/*!40000 ALTER TABLE `parents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-12 20:57:08
