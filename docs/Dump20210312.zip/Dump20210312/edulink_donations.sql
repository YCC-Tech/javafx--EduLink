-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: edulink
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `donations`
--

DROP TABLE IF EXISTS `donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `donations` (
  `donation_id` int NOT NULL AUTO_INCREMENT,
  `donator_id` int NOT NULL,
  `amount` int NOT NULL,
  `donated_at` date NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`donation_id`),
  KEY `fk_donations_donators1_idx` (`donator_id`),
  CONSTRAINT `fk_donations_donators1` FOREIGN KEY (`donator_id`) REFERENCES `donators` (`donator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donations`
--

LOCK TABLES `donations` WRITE;
/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
INSERT INTO `donations` VALUES (1,1,100000,'2021-01-01','Birthday donation'),(2,2,200000,'2021-01-15','Wedding aniversity donation'),(3,3,500000,'2021-01-30','Monthly donation'),(4,4,150000,'2021-02-02','Monthly donation'),(5,5,200000,'2021-02-17','Friends together donation'),(6,1,1000,'2021-03-09','desc'),(7,9,9199,'2021-03-09','dkjf'),(8,10,10000,'2021-03-09','dkfjskdfj'),(9,11,93849,'2021-03-09','dkfjksdjf'),(10,12,999,'2021-03-09','kdjfklsjdf'),(11,13,23233,'2021-03-09','dfsdfsdfs'),(12,3,111222,'2021-03-09','dfdf'),(13,14,3434,'2021-03-11','dkfjsdklf'),(14,15,100000,'2021-03-11','Birthday Donation'),(15,15,150000,'2021-03-11','Another birthday'),(16,16,150000,'2021-03-12','Birthday donation...'),(17,16,200000,'2021-03-12','Another donation.'),(18,1,100,'2021-03-12','From Bank');
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-12 20:57:07
