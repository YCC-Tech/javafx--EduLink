-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: edulink
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `majors`
--

DROP TABLE IF EXISTS `majors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `majors` (
  `major_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `short_name` varchar(20) DEFAULT NULL,
  `university_id` int NOT NULL,
  `attendance_year_id` int NOT NULL,
  PRIMARY KEY (`major_id`),
  KEY `fk_majors_universities1_idx` (`university_id`),
  KEY `fk_majors_attendance_years1_idx` (`attendance_year_id`),
  CONSTRAINT `fk_majors_attendance_years1` FOREIGN KEY (`attendance_year_id`) REFERENCES `attendance_years` (`attendance_year_id`),
  CONSTRAINT `fk_majors_universities1` FOREIGN KEY (`university_id`) REFERENCES `universities` (`university_id`)
) ENGINE=InnoDB AUTO_INCREMENT=243 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `majors`
--

LOCK TABLES `majors` WRITE;
/*!40000 ALTER TABLE `majors` DISABLE KEYS */;
INSERT INTO `majors` VALUES (1,'Information and Communication Technology Engineering','ICT',1,1),(2,'Information and Communication Technology Engineering','ICT',1,2),(3,'Information Science Technology','IS',1,3),(4,'Information Science Technology','IS',1,4),(5,'Information Science Technology','IS',1,5),(6,'Information Science Technology','IS',1,6),(7,'Electronics Engineering','EcE',1,1),(8,'Electronics Engineering','EcE',1,2),(9,'Electronics Engineering','EcE',1,3),(10,'Electronics Engineering','EcE',1,4),(11,'Electronics Engineering','EcE',1,5),(12,'Electronics Engineering','EcE',1,6),(13,'Mechanical Precision & Automation Engineering','PrE',1,1),(14,'Mechanical Precision & Automation Engineering','PrE',1,2),(15,'Mechanical Precision & Automation Engineering','PrE',1,3),(16,'Mechanical Precision & Automation Engineering','PrE',1,4),(17,'Mechanical Precision & Automation Engineering','PrE',1,5),(18,'Mechanical Precision & Automation Engineering','PrE',1,6),(19,'Advanced Material Engineering','AME',1,1),(20,'Advanced Material Engineering','AME',1,2),(21,'Advanced Material Engineering','AME',1,3),(22,'Advanced Material Engineering','AME',1,4),(23,'Advanced Material Engineering','AME',1,5),(24,'Advanced Material Engineering','AME',1,6),(25,'General','General',2,7),(26,'General','General',2,8),(27,'General','General',2,9),(28,'General','General',2,10),(29,'General','General',2,11),(30,'General','General',2,12),(31,'General','General',3,13),(32,'General','General',3,14),(33,'General','General',3,15),(34,'General','General',3,16),(35,'General','General',3,17),(36,'Civil Engineering','Civil',4,18),(37,'Civil Engineering','Civil',4,19),(38,'Civil Engineering','Civil',4,20),(39,'Civil Engineering','Civil',4,21),(40,'Civil Engineering','Civil',4,22),(41,'Civil Engineering','Civil',4,23),(42,'Architecture','Architect',4,18),(43,'Architecture','Architect',4,19),(44,'Architecture','Architect',4,20),(45,'Architecture','Architect',4,21),(46,'Architecture','Architect',4,22),(47,'Architecture','Architect',4,23),(48,'Mechanical Engineering','ME',4,18),(49,'Mechanical Engineering','ME',4,19),(50,'Mechanical Engineering','ME',4,20),(51,'Mechanical Engineering','ME',4,21),(52,'Mechanical Engineering','ME',4,22),(53,'Mechanical Engineering','ME',4,23),(54,'Electrical Power Engineering','EP',4,18),(55,'Electrical Power Engineering','EP',4,19),(56,'Electrical Power Engineering','EP',4,20),(57,'Electrical Power Engineering','EP',4,21),(58,'Electrical Power Engineering','EP',4,22),(59,'Electrical Power Engineering','EP',4,23),(60,'Electronic Engineering','EcE',4,18),(61,'Electronic Engineering','EcE',4,19),(62,'Electronic Engineering','EcE',4,20),(63,'Electronic Engineering','EcE',4,21),(64,'Electronic Engineering','EcE',4,22),(65,'Electronic Engineering','EcE',4,23),(66,'Mechatronics Engineering','Mechatronics',4,18),(67,'Mechatronics Engineering','Mechatronics',4,19),(68,'Mechatronics Engineering','Mechatronics',4,20),(69,'Mechatronics Engineering','Mechatronics',4,21),(70,'Mechatronics Engineering','Mechatronics',4,22),(71,'Mechatronics Engineering','Mechatronics',4,23),(72,'Information Technological','IT',4,18),(73,'Information Technological','IT',4,19),(74,'Information Technological','IT',4,20),(75,'Information Technological','IT',4,21),(76,'Information Technological','IT',4,22),(77,'Information Technological','IT',4,23),(78,'Chemical engineering','Chemical',4,18),(79,'Chemical engineering','Chemical',4,19),(80,'Chemical engineering','Chemical',4,20),(81,'Chemical engineering','Chemical',4,21),(82,'Chemical engineering','Chemical',4,22),(83,'Chemical engineering','Chemical',4,23),(84,'Petroleum Engineering','Petroleum',4,18),(85,'Petroleum Engineering','Petroleum',4,19),(86,'Petroleum Engineering','Petroleum',4,20),(87,'Petroleum Engineering','Petroleum',4,21),(88,'Petroleum Engineering','Petroleum',4,22),(89,'Petroleum Engineering','Petroleum',4,23),(90,'Mining Engineering','Mining',4,18),(91,'Mining Engineering','Mining',4,19),(92,'Mining Engineering','Mining',4,20),(93,'Mining Engineering','Mining',4,21),(94,'Mining Engineering','Mining',4,22),(95,'Mining Engineering','Mining',4,23),(96,'Biotechnology','Biotech',4,18),(97,'Biotechnology','Biotech',4,19),(98,'Biotechnology','Biotech',4,20),(99,'Biotechnology','Biotech',4,21),(100,'Biotechnology','Biotech',4,22),(101,'Biotechnology','Biotech',4,23),(102,'General','General',5,24),(103,'General','General',5,25),(104,'Computer Science','CS',5,26),(105,'Computer Technology','CT',5,26),(106,'Software Engineering','SE',5,27),(107,'Software Engineering','SE',5,28),(108,'Business Information Systems','BIS',5,27),(109,'Business Information Systems','BIS',5,28),(110,'Knowledge Engineering','KE',5,27),(111,'Knowledge Engineering','KE',5,28),(112,'High Performance Computing','HPC',5,27),(113,'High Performance Computing','HPC',5,28),(114,'Embedded Systems','Embedded',5,27),(115,'Embedded Systems','Embedded',5,28),(116,'Communication and Networking','Networking',5,27),(117,'Communication and Networking','Networking',5,28),(118,'Computer Systems','Computer Systems',5,27),(119,'Computer Systems','Computer Systems',5,28),(120,'Computer Engineering','CE',1,3),(121,'Computer Engineering','CE',1,4),(122,'Computer Engineering','CE',1,5),(123,'Computer Engineering','CE',1,6);
/*!40000 ALTER TABLE `majors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-12 20:57:04
